from enc_dec import encrypt, decrypt
import sys
SERVER_ID = "B"

def checkandDecMessageswithBlocking(netif, key):
    status, msg = netif.receive_msg(blocking=True)
    if status:
        command, result, message, ctr, id = decrypt(key.encode('latin1'), msg, netif )
        command = command.decode('ascii')[:-1]
		##Check to make sure message is from the server
        if(id.decode()[0] != SERVER_ID):
            print("Invalid Sender")
            sys.exit(1)
        if (command == "CRC"):
            return True, result, message
        elif(command == "CTE"):
            print("Terminating Session")
            print("Reason: Counter Error")
            sys.exit(1)
        else:
            return False, result, message

## I don't think we ever use this?
def checkandDecMessageswithoutBlocking(netif, key):
    print("Checking server response...")
    status, msg = netif.receive_msg(blocking=False)
    if status:
         command, result, message = decrypt(key.encode('latin1'), msg, netif)
         print("command: ", command)
         print("result: ", result)
         print("message: ", message)
		 #return result, message
    else:
         print("no messages recieved")
