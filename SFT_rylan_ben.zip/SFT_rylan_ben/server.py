import os, sys, getopt, time
from netinterface import network_interface
from datetime import datetime, timedelta

from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from Crypto.Cipher import AES
from Crypto import Random
from enc_dec import encrypt, decrypt
from pathlib import Path


#network path will always be ./
NET_PATH = './'
OWN_ADDR = 'B'

# ------------
# main program
# ------------

try:
	opts, args = getopt.getopt(sys.argv[1:], shortopts='h', longopts=['help'])
except getopt.GetoptError:
	print('Usage: python server.py')
	sys.exit(1)

for opt, arg in opts:
	if opt == '-h' or opt == '--help':
		print('Usage: python server.py')
		sys.exit(0)

if not os.access(NET_PATH, os.F_OK):
	print('Error: Cannot access path ' + NET_PATH)
	sys.exit(1)

if len(OWN_ADDR) > 1: OWN_ADDR = OWN_ADDR[0]

if OWN_ADDR not in network_interface.addr_space:
	print('Error: Invalid address ' + OWN_ADDR)
	sys.exit(1)

##Obtain public and private keys for RSA
private_key = ""
with open('private_key.pem', "rb") as f:
    private_key = RSA.import_key(f.read())

public_key = ""
with open("public_key.pem", "rb") as f:
	public_key = RSA.import_key(f.read())


#Define Constants
cipher_decrypt = PKCS1_OAEP.new(private_key)
cipher_encrypt = PKCS1_OAEP.new(public_key)
mainDir = "SERVER/"
currDir = mainDir
CTR_send = 0
CTR_recieve = 0

#send the session establishment verificatin message to the client
def send_verification_msg(msg, key):
	nonce = Random.get_random_bytes(8)
	message = msg
	authtag_length = 12
	AE = AES.new(key, AES.MODE_GCM, nonce=nonce, mac_len = authtag_length)
	AE.update(nonce)
	encrypted_payload, authtag = AE.encrypt_and_digest(msg.encode('ascii'))
	message = nonce + encrypted_payload + authtag
	netif.send_msg(client_addr, message)



#method when a password is recieved from the client
def on_pwd_receive(user_id, pwd_attempt, key,dst):
	dir = './SERVER/Passwords/' + user_id
	path = dir + '/password.txt'
	#check if the user already exists
	if os.path.exists(path):
		#if they do try and verify their passowrd
		with open(path, 'rb') as file:
			user_pwd = file.read()
			decrypted_pwd = cipher_decrypt.decrypt(user_pwd)
			decrypted_pwd = decrypted_pwd.decode()
			if(pwd_attempt == decrypted_pwd):
				encrypt(OWN_ADDR, key, "CRC", "SUCCESS!", "Password verified successfully", 0,dst, netif)
				print("Password verified successfully")
				return True
			else:
				encrypt(OWN_ADDR, key, "CRC", "FAIL!", "Password Incorrect!", 0,dst, netif)
				print("Incorrect password!!")
				print("Terminating session...")
				#sys.exit(1)
				return False
	#if the user does not exist, create a directory for them
	else:
		os.mkdir(dir)
		new_dir = './SERVER/' + user_id
		os.mkdir(new_dir)
		with open(path, 'wb') as file:
			encrypted_pwd = cipher_encrypt.encrypt(pwd_attempt.encode('utf-8'))
			file.write(encrypted_pwd)
			message = "Registered new user with id: " + dst
			encrypt(OWN_ADDR, key, "CRC", "NEWUSER", message, 0,dst, netif)
			print("New user registered")
			return True


#A method to detect if anoter user is trying to log in
#when a session is already established
def detect_attempted_establishment(msg):
	try:
		decrypt_msg = cipher_decrypt.decrypt(msg)
		decrypt_msg = decrypt_msg.decode()
		response = "SERVBUSY"
		new_dst = decrypt_msg[0]
		attempt_session_key = decrypt_msg[26:]
		nonce = Random.get_random_bytes(8)
		authtag_length = 12
		AE = AES.new(attempt_session_key.encode('latin1'), AES.MODE_GCM, nonce=nonce, mac_len = authtag_length)
		AE.update(nonce)
		encrypted_payload, authtag = AE.encrypt_and_digest(response.encode('ascii'))
		message = nonce + encrypted_payload + authtag
		netif.send_msg(new_dst, message)
		return True
	except:
		return False


#helper for displaying content to cleint
def display_directory_to_client(directory):
	return directory[7:] + "/"


## The following methods define ths servers behavior upon
## receiving valid commands from the client
def receive_mkd(CTR_send):
	print("Command received: Making a new directory")
	addPath = os.path.join(currDir + "/" + fileName)
	if(os.path.exists(addPath) == False):
		try:
			os.mkdir(addPath)
			encrypt(OWN_ADDR, session_key.encode('latin1'), "CRC", "Command Recieved: create directory = sucessful", "", CTR_send, client_addr, netif)
			CTR_send += 1
			print("Successfully created directory")
		except OSError:
			print(OSError)
			encrypt(OWN_ADDR, session_key.encode('latin1'), "CFC", "OS exception", "", CTR_send, client_addr, netif)
			CTR_send += 1
			print("Error creating directory: OS Error")
	else:
		encrypt(OWN_ADDR, session_key.encode('latin1'), "CFC", "Directory already exists!", "", CTR_send, client_addr, netif)
		CTR_send += 1
		print("Error creating directory: Directory already exists")
	return CTR_send


def receive_rmd(CTR_send):
	print("Command received: Removing a directory")
	remPath = os.path.join(os.getcwd(), currDir + "/" + fileName)
	if(os.path.exists(remPath)):
		if(len(os.listdir(remPath)) == 0):
			try:
				os.rmdir(remPath)
				encrypt(OWN_ADDR, session_key.encode('latin1'), "CRC", "Command Received: remove File sucessful", "", CTR_send, client_addr, netif)
				CTR_send += 1
				print("Successfully removed directory")
			except:
				encrypt(OWN_ADDR, session_key.encode('latin1'), "CFC", "OS exception", "", CTR_send, client_addr, netif)
				CTR_send += 1
				print("Error removing directory: OS Error")
		else:
			encrypt(OWN_ADDR, session_key.encode('latin1'), "CFC", "Directory is not empty", "", CTR_send, client_addr, netif)
			CTR_send += 1
			print("Error removing directory: Directory cannot be empty")
	else:
		encrypt(OWN_ADDR, session_key.encode('latin1'), "CFC", "Directory not found", "", CTR_send, client_addr, netif)
		CTR_send += 1
		print("Error removing directory: Directory not found")
	return CTR_send

def receive_gwd(CTR_send):
	print("Command received: getting working directory")
	encrypt(OWN_ADDR, session_key.encode('latin1'), "CRC", display_directory_to_client(currDir), "", CTR_send, client_addr, netif)
	CTR_send += 1
	print("Successfully retreived working directory")
	return CTR_send

def receive_cwd(currDir, CTR_send):
	print("Command received: changeing working directory")
	changePath = os.path.join(currDir + "/" + fileName)
	if (os.path.isdir(os.path.join(os.getcwd(),changePath))):
		currDir = changePath
		encrypt(OWN_ADDR, session_key.encode('latin1'), "CRC", "Command: change directory sucessful", "", CTR_send, client_addr, netif)
		CTR_send += 1
		print("Successfully changed directory")
		return changePath, CTR_send
	else:
		encrypt(OWN_ADDR, session_key.encode('latin1'), "CFC", "Could not find directory", "", CTR_send, client_addr, netif)
		CTR_send += 1
		print("Error changing directory: Could not find directory")
		return currDir, CTR_send

def receive_crd(CTR_send):
	print("Command received: changing to root directory")
	encrypt(OWN_ADDR, session_key.encode('latin1'), "CRC", "Command: change to root directory sucessful", "", CTR_send, client_addr, netif)
	CTR_send += 1
	print("Successfully changed to root directory")
	return mainDir, CTR_send

def receive_cnf(CTR_send):
	print("Command received: Creating a file")
	fileCreate = currDir + "/"
	fileCreate += fileName
	if(os.path.exists(fileName) == False):
		try:
			encrypted_contents = cipher_encrypt.encrypt(fileContents.encode('utf-8'))
			with open(fileCreate, 'wb') as file:
				file.write(encrypted_contents)
			encrypt(OWN_ADDR, session_key.encode('latin1'), "CRC", "Command Received: create File sucessful", "", CTR_send, client_addr, netif)
			CTR_send += 1
			print("Successfully created file")
		except:
			print("Error While Creating File")
			encrypt(OWN_ADDR, session_key.encode('latin1'), "CFC", "Creating File failed", "", CTR_send, client_addr, netif)
			CTR_send += 1
			print("Error creating file: OS error")
	else:
		encrypt(OWN_ADDR, session_key.encode('latin1'), "CFC", "File already exists!", "", CTR_send, client_addr, netif)
		CTR_send += 1
		print("Error creating file: file already exists")
	return CTR_send

def receive_lst(currDir, CTR_send):
	print("Command received: Listing current file directory")
	dirString = str(os.listdir(currDir))
	encrypt(OWN_ADDR, session_key.encode('latin1'), "CRC", dirString, "Command Recieved: sent ls of current directory", CTR_send, client_addr, netif)
	CTR_send += 1
	print("Successfully listed directory contents")
	return CTR_send

def receive_dwn(currDir, CTR_send):
	print("Command: Downloading A File to Client")
	fileDownload = currDir + "/"
	fileDownload += fileName
	if(os.path.exists(fileDownload)):
		try:
			with open(fileDownload, 'rb') as file:
				file_contents = file.read()
				decrypted_contents = cipher_decrypt.decrypt(file_contents)
				decrypted_contents = decrypted_contents.decode()
				contents = decrypted_contents
			encrypt(OWN_ADDR, session_key.encode('latin1'), "CRC", fileName, contents, CTR_send, client_addr, netif)
			CTR_send += 1
			print("Successfully retreived file for download")
		except:
			print("Error downloading file: Could not read file")
			encrypt(OWN_ADDR, session_key.encode('latin1'), "CFC", "Error downloading file", "", CTR_send, client_addr, netif)
			CTR_send += 1
	else:
		print("Error downloading file: Could not find file")
		encrypt(OWN_ADDR, session_key.encode('latin1'), "CFC", "Could not find file", "", CTR_send, client_addr, netif)
		CTR_send += 1
	return CTR_send



def receive_rmf(currDir, CTR_send):
	print("Command Received: Removing a File")
	fileDelete = currDir + "/"
	fileDelete += fileName
	if os.path.exists(fileDelete):
		try:
			os.remove(fileDelete)
			encrypt(OWN_ADDR, session_key.encode('latin1'), "CRC", "Command Recieved: Deleted File" , "", CTR_send, client_addr, netif)
			CTR_send += 1
			print("Successfully removed file")
		except:
			encrypt(OWN_ADDR, session_key.encode('latin1'), "CFC", "OS Error", "", CTR_send, client_addr, netif)
			CTR_send += 1
			print("Error removing file: OS erro")

	else:
		encrypt(OWN_ADDR, session_key.encode('latin1'), "CFC", "Could not find file", "", CTR_send, client_addr, netif)
		CTR_send += 1
		print("Error removing file: could not find file")
	return CTR_send

def receive_upl(currDir, CTR_send):
	print("Command recieved: Uplolading a file")
	fileUpload = currDir + "/"
	fileUpload += fileName
	print(fileUpload)
	if(os.path.exists(fileUpload) == False):
		try:
			with open(fileUpload, 'wb') as file:
				encrypted_contents = cipher_encrypt.encrypt(fileContents.encode('utf-8'))
				file.write(encrypted_contents)
				encrypt(OWN_ADDR, session_key.encode('latin1'), "CRC", "Command Received: Uploading File sucessful", "", CTR_send, client_addr, netif)
				CTR_send += 1
				print("Successfully uploaded file")
		except:
			print("Error uploading file: OS Error")
			encrypt(OWN_ADDR, session_key.encode('latin1'), "CFC", "OS Error", "", CTR_send, client_addr, netif)
			CTR_send += 1
	else:
		print("Error uploading file: File already exists")
		encrypt(OWN_ADDR, session_key.encode('latin1'), "CFC", "File already exists", "", CTR_send, client_addr, netif)
		CTR_send += 1
	return CTR_send

def receive_ecs(CTR_send):
	print("Command received: Ending current Session...")
	encrypt(OWN_ADDR, session_key.encode('latin1'), "CRC", "Command Recieved: ending current session", "", CTR_send, client_addr, netif)
	CTR_send += 1
	return False, CTR_send

def counter_error():
	print("Terminatin session...")
	print("Reason: Counter Error")
	encrypt(OWN_ADDR, session_key.encode('latin1'), "CTE", "Counter Error: ending current session", "", 0, client_addr, netif)
	sys.exit(1)


# main loop
netif = network_interface(NET_PATH, OWN_ADDR)
print('Server online...')
while True:
	mainDir = "SERVER/"
	currDir = mainDir
	CTR_send = 0
	CTR_recieve = 0
	print('Wating for session establishment...')
	##First loop to establish session with client
	establish_attempt = False
	while establish_attempt == False:
		status, msg = netif.receive_msg(blocking=True)    # when returns, status is True and msg contains a message
		if status:
			##the first message should be establishing a session
			establish_attempt = True
			decrypted_message = cipher_decrypt.decrypt(msg)
			decrypted_message = decrypted_message.decode()
			client_addr = decrypted_message[0]
			time_stamp = decrypted_message[1:18]
			time_object = datetime.strptime(time_stamp, '%m/%d/%y %H:%M:%S')
			confirmation = decrypted_message[18:26]
			session_key = decrypted_message[26:]

			#check for freshness
			if time_object > datetime.now()-timedelta(seconds=3):
				mainDir = "SERVER/" + client_addr
				currDir = mainDir
				print("Attempting to establish session with client...")
				send_verification_msg(confirmation, session_key.encode('latin1'))
			else:
				print("Error: Session establishment not fresh")
				print("Ending session...")
				#sending fail message back to client
				send_verification_msg("FAIL", session_key.encode('latin1'))
				sys.exit(1)

	##Next loop authenticates client with password
	print("Waiting for password from client...")
	pwd_accepted = False
	#while pwd_accepted == False:
	pwd_received = False
	while pwd_received == False:
		status, msg = netif.receive_msg(blocking=True)
		if status:
			if detect_attempted_establishment(msg):
				print("Secondary Establishment Attempt Detected...")
				print("Rejecting establishment, currently in use")
				print("Waiting for password from user ", client_addr)
			else:
				pwd_received = True
				command, filename, message, ctr, id = decrypt(session_key.encode('latin1'), msg, netif)
				if(command.decode()[:3] == "LGN"):
					pwd_accepted = on_pwd_receive(client_addr, message.decode(), session_key.encode('latin1'), client_addr)
				#client will end session if werver is not verified, so
				#server will end session too
				if(command.decode()[:3] == "ECS"):
					print("Client terminated session, reason:")
					print(message.decode())
					print("Ending current session...")
					pwd_accepted = False
	if(pwd_accepted == False):
		continue

	#Start the main session loop
	print("Beginning session with user: " + client_addr)
	session_running = True
	while session_running:
		status, msg = netif.receive_msg(blocking=True)
		if (status == True) and (detect_attempted_establishment(msg)):
			print("Secondary Establishment Attempt Detected...")
			print("Rejecting establishment, currently in use")

		else:
			commandInput, fileName, fileContents, ctr, id = decrypt(session_key.encode('latin1'), msg, netif)
			command = commandInput.decode('ascii')[:-1]
			fileName = fileName.decode('ascii')
			fileContents = fileContents.decode('ascii')
			ctr = int.from_bytes(ctr, byteorder='big')
			if ctr == (CTR_recieve):
				CTR_recieve+=1
			else:
				counter_error()
			if command == "ECS":
				session_running, CTR_send = receive_ecs(CTR_send)
			elif command == "LST":
				CTR_send = receive_lst(currDir, CTR_send)
			elif command == "GWD":
				CTR_send = receive_gwd(CTR_send)
			elif command == "CWD":
				currDir, CTR_send = receive_cwd(currDir, CTR_send)
			elif command == "CRD":
				currDir, CTR_send = receive_crd(CTR_send)
			elif command == "MKD":
				CTR_send = receive_mkd(CTR_send)
			elif command == "RMD":
				CTR_send = receive_rmd(CTR_send)
			elif command == "CNF":
				CTR_send = receive_cnf(CTR_send)
			elif command == "UPL":
				CTR_send = receive_upl(currDir, CTR_send)
			elif command == "DWN":
				CTR_send = receive_dwn(currDir, CTR_send)
			elif command == "RMF":
				CTR_send = receive_rmf(currDir, CTR_send)
			else:
				print(" >> ERROR : Command not recognized")

	print("End of Session")
	#sys.exit(1)
