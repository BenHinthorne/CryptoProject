import os, sys, getopt, time
from netinterface import network_interface
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from Crypto.Cipher import AES
from Crypto import Random
from datetime import datetime
from enc_dec import encrypt, decrypt
#from client_helper import checkandDecMessageswithBlocking
#from client_helper import checkandDecMessageswithBlocking

#netpath will always just be current directory
NET_PATH = './'
OWN_ADDR = 'A'

# ------------
# main program
# ------------
# owd for user a
try:
	opts, args = getopt.getopt(sys.argv[1:], shortopts='ha:', longopts=['help', 'addr='])
except getopt.GetoptError:
	print('Usage: python client.py -a <own addr>')
	sys.exit(1)

for opt, arg in opts:
	if opt == '-h' or opt == '--help':
		print('Usage: python client.py -a <own addr>')
		sys.exit(0)
	elif opt == '-a' or opt == '--addr':
		OWN_ADDR = arg

if not os.access(NET_PATH, os.F_OK):
	print('Error: Cannot access path ' + NET_PATH)
	sys.exit(1)

if len(OWN_ADDR) > 1: OWN_ADDR = OWN_ADDR[0]

if OWN_ADDR not in network_interface.addr_space:
	print('Error: Invalid address ' + OWN_ADDR)
	sys.exit(1)
if OWN_ADDR == "B":
	print("Invalid address, adress B reserved for the server" )
	sys.exit(1)


#Defining Constants
netif = network_interface(NET_PATH, OWN_ADDR)
dst = "B"   ##B is our pre-defined server destination
confirmation = "SUCCESS!"
CTR_send = 0
CTR_receive = 0



def checkandDecMessageswithBlocking(netif, key, CTR_receive):
    status, msg = netif.receive_msg(blocking=True)
    if status:
        command, result, message, ctr, id = decrypt(key.encode('latin1'), msg, netif )
        command = command.decode('ascii')[:-1]
        ctr = int.from_bytes(ctr, byteorder='big')
		##Check to make sure message is from the server
        if(id.decode()[0] != dst):
            print("Invalid Sender")
        if (ctr != CTR_receive):
            print("Terminating Session")
            print("Reason: Server CTR Error")
            handle_ECS()
            sys.exit(1)
        if (command == "CRC"):
            return True, result, message
        elif(command == "CTE"):
            print("Terminating Session")
            print("Reason: Counter Error")
            sys.exit(1)
        else:
            return False, result, message

## Sends the message to the server to initiate session
def establish_session(key):
	#obtain public key
	public_key = ""
	with open("public_key.pem", "rb") as f:
		public_key = RSA.import_key(f.read())
	cipher_encrypt = PKCS1_OAEP.new(public_key)

	#create message
	time_stamp = str(datetime.now().strftime('%m/%d/%y %H:%M:%S'))
	msg = OWN_ADDR + time_stamp + confirmation + key

	#encrypt and send establishment message to server
	ciphertext = cipher_encrypt.encrypt(msg.encode('utf-8'))
	netif.send_msg(dst, ciphertext)


#decode the verification message from the server
def verify_server(msg, key):
	nonce = msg[0:8]
	contents = msg[8:16]
	authtag = msg[-12:]
	authtage_len = 12
	AE = AES.new(key, AES.MODE_GCM, nonce = nonce, mac_len = authtage_len)
	AE.update(nonce)
	try:
		payload = AE.decrypt_and_verify(contents, authtag)
	except Exception as e:
		print("Error: Operation failed!")
		print("Terminating Session.")
		sys.exit(1)
	return payload.decode('ascii')

#check if the server has been successfully authenticated
def server_auth_response(response):
	if response == confirmation:
		print("Server verified successfully!")
		return True
	elif response == "FRESHNESS_ERROR":
		print("Server terminated session")
		print("Reason: ", response)
		sys.exit(1)
	elif response == "SERVBUSY":
		print("Terminating session")
		print("Reason: Server in use")
		sys.exit(1)
	else:
		print("Server verificaton failed, terminating session")
		fail_message = "AUTHENTICATION FAILURE"
		##if authentication has failed, send a fail message to server to end the session
		encrypt(OWN_ADDR, key.encode('latin1'), "ECS", "", fail_message, 0, dst, netif)
		sys.exit(1)


#check if the password has been accepted
def server_pwd_response(msg):
	command, result, message, ctr, id = decrypt(key.encode('latin1'), msg, netif)
	if(result.decode() == "SUCCESS!"):
		print("Successfully logged in!")
		return True
	elif(result.decode() == "NEWUSER"):
		print("You have been successfully registered as a new user!")
		return True
	if(result.decode() == "FAIL!"):
		print(message.decode())
		print("Terminating session...")
		sys.exit(1)


## Loop to establish session
while True:
	print("Initiating session...")
	print("Generating session key...")
	key = os.urandom(16).decode('latin1')
	print("Key Generated")
	establish_session(key)

	print("Wating for server verification...")
	server_verified = False
	currentTime = time.time()
	while server_verified == False:
		##Timeout if the server doesn't respond in 10 seconds
		status, msg = netif.receive_msg(blocking=False)
		if((time.time() - currentTime) > 10):
			print("It appears the sevrver is not online, or your address space is not in the network")
			print("Please try establishing a session when the server is online,and make sure your address space is in the network")
			sys.exit(1)
		if(status == True):
		    response = verify_server(msg, key.encode('latin1'))
		    server_verified = server_auth_response(response)
	if(server_verified == False):
		break
	else:
		password = input("Input your password: ")
		encrypt(OWN_ADDR, key.encode('latin1'), "LGN", "", password, 0, dst, netif)

	print("Waiting for server to verify password...")
	password_accepted = False
	while(password_accepted == False):
		status, msg = netif.receive_msg(blocking=True)
		password_accepted = server_pwd_response(msg)
	break



## The Following methods define the behavior for each valid command
## During a session
def handle_mkd():
	createFileName = input("Name of directory: ")
	encrypt(OWN_ADDR, key.encode('latin1'), "MKD", createFileName, "Make a Dir", CTR_send, dst, netif)
	global CTR_receive
	ans, result, message = checkandDecMessageswithBlocking(netif, key, CTR_receive)
	CTR_receive += 1
	if(ans):
		res = "Folder created successfully"
		print(res)
	else:
		print("Directory creation failed: ", result.decode())

def handle_rmd():
	remInput = ""
	while(remInput == ""):
		remInput = input("Name of directory to remove: ")
	global CTR_receive
	encrypt(OWN_ADDR, key.encode('latin1'), "RMD", remInput, "Remove a directory", CTR_send, dst, netif)
	ans,res,message = checkandDecMessageswithBlocking(netif, key, CTR_receive)
	CTR_receive += 1
	if(ans):
		res = "Directory removed successfully"
		print(res)
	else:
		print("Directory removal failed: ", res.decode())

def handle_gwd():
	encrypt(OWN_ADDR, key.encode('latin1'), "GWD", "", "Get your current Dir", CTR_send, dst, netif)
	global CTR_receive
	ans, res, message = checkandDecMessageswithBlocking(netif, key, CTR_receive)
	CTR_receive += 1
	if(ans):
		print(res.decode())
	else:
		print("Error getting directory")

def handle_cwd():
	cwdInput = input("What directory do you want to move into: ")
	global CTR_receive
	encrypt(OWN_ADDR, key.encode('latin1'), "CWD", cwdInput, "change to directory", CTR_send, dst, netif)
	ans,res,message = checkandDecMessageswithBlocking(netif, key, CTR_receive)
	CTR_receive += 1
	if(ans):
		print("Directory changed successfully")
	else:
		print("Error changing directory: ", res.decode())

def handle_crd():
	encrypt(OWN_ADDR, key.encode('latin1'), "CRD", "", "change to root directory", CTR_send, dst, netif)
	global CTR_receive
	ans,res,message = checkandDecMessageswithBlocking(netif, key, CTR_receive)
	CTR_receive += 1
	if(ans):
		print("Successfully moved to root directory")
	else:
		print("Error moving to root directory")

def handle_lst():
	encrypt(OWN_ADDR, key.encode('latin1'), "LST", "", "List curr directory contents", CTR_send, dst, netif)
	global CTR_receive
	ans,res, message = checkandDecMessageswithBlocking(netif, key, CTR_receive)
	CTR_receive += 1
	if(ans):
		string_res = res.decode()[1:-1]
		list_res = string_res.split(",")
		for val in list_res:
			print(val.replace("\'","").strip())
	else:
		print("Error getting directory contents")

def handle_cnf():
	fileNameInput = input("Name of file to create: ")
	fileContentsInput = input("Contents of file: ")
	encrypt(OWN_ADDR, key.encode('latin1'), "CNF", fileNameInput, fileContentsInput, CTR_send, dst, netif)
	global CTR_receive
	ans,res,message = checkandDecMessageswithBlocking(netif, key, CTR_receive)
	CTR_receive += 1
	if(ans):
		print("File created successfully")
	else:
		print("Error creating file: ", res.decode())

def handle_dwn():
        fileNameInput = input("Name of file to download: ")
        encrypt(OWN_ADDR, key.encode('latin1'), "DWN", fileNameInput, "", CTR_send, dst, netif)
        global CTR_receive
        ans, res, contents = checkandDecMessageswithBlocking(netif, key, CTR_receive)
        CTR_receive += 1
        if(ans):
            try:
                with open(res.decode(), 'w') as file:
                    file.write(contents.decode())
                file_loc = os.getcwd() + "\\" + res.decode()
                print("File downloaded successfully")
            except:
                print("Client error downloading file")
        else:
            print("Error downloading file: ", res.decode())

def handle_rmf():
	fileNameInput = input("Name of file to remove: ")
	encrypt(OWN_ADDR, key.encode('latin1'), "RMF", fileNameInput, "", CTR_send, dst, netif)
	global CTR_receive
	ans,res,message = checkandDecMessageswithBlocking(netif, key, CTR_receive)
	CTR_receive += 1
	if(ans):
		print("File removed successfully")
	else:
		print("Error removing file: ", res.decode())

def handle_upl():
	file_name = input("Name of the file to upload: ")
	file_path = os.getcwd() + "\\" + file_name
	contents = ""
	if os.path.exists(file_path):
		#retrieve contents of cleint file
		try:
			with open(file_path, 'r') as file:
				contents = file.read()
			#send file name and contents to server
			encrypt(OWN_ADDR, key.encode('latin1'), "UPL", file_name, contents, CTR_send, dst, netif)
			global CTR_receive
			ans,res,message = checkandDecMessageswithBlocking(netif, key, CTR_receive)
			CTR_receive += 1
			if(ans):
				print("File uploaded successfully")
				return True
			else:
				print("Error uploading file: ", res.decode())
				return True
		except:
			print("Error uploading file: OS exception")
			return False
	else:
		print("File not found!!")
		return False

def handle_ECS():
	encrypt(OWN_ADDR, key.encode('latin1'), "ECS", "", "End Current Session", CTR_send, dst, netif)
	global CTR_receive
	ans,res,message = checkandDecMessageswithBlocking(netif, key, CTR_receive)
	CTR_receive += 1
	if ans:
		print("Ending current session...")
	return False

def print_help_commands():
    print("Supported Commands: ")
    print("MKD: Make a directory")
    print("RMD: Remove a directory")
    print("GWD: Obtain the name of the current directory on the server")
    print("CWD: Change the current folder on the server.")
    print("LST: List the contents of the current directory")
    print("CNF: Create a new file on the server")
    print("UPL: Upload a file to the server")
    print("DWN: Download a file from the server")
    print("RMF: Remove a file")
    print("ECS: End current session")
    print("")





#Loop for session behavior
print("Beginning Session...")
session_running = True
while session_running:
    print("Wating for next command...")
    print("[type h for help][type ECS to end current session] ")
    command = input("Enter command here: ")

    if command == "h":
        print_help_commands()
    elif command == "MKD":
        handle_mkd()
        CTR_send+=1
    elif command == "RMD":
        handle_rmd()
        CTR_send+=1
    elif command == "GWD":
        handle_gwd()
        CTR_send += 1
    elif command == "CWD":
        handle_cwd()
        CTR_send += 1
    elif command == "CRD":
        handle_crd()
        CTR_send += 1
    elif command == "LST":
        handle_lst()
        CTR_send += 1
    elif command == "CNF":
        handle_cnf()
        CTR_send += 1
    elif command == "DWN":
        handle_dwn()
        CTR_send += 1
    elif command == "RMF":
        handle_rmf()
        CTR_send += 1
    elif command == "ECS":
        session_running = handle_ECS()
    elif command == "UPL":
        if(handle_upl()):
            CTR_send += 1
    else:
        print(">> Error >> Please enter a supported command")
    print("")

print("Session Over")
