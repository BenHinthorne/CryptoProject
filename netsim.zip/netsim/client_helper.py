from enc_dec import encrypt, decrypt

def checkandDecMessageswithBlocking(netif, key):
	print("checking Messages")
	status, msg = netif.receive_msg(blocking=True)
	if status:
         command, result, message, ctr = decrypt(key.encode('ascii'), msg, netif )
         command = command.decode('ascii')[:-1]
         print("command: ", command)
         print("result: ", result)
         print("message: ", message)
         if (command == "CRC"):
              return True
         else:
              return False

def checkandDecMessageswithoutBlocking(netif, key):
    print("checking Messages")
    status, msg = netif.receive_msg(blocking=False)
    if status:
         command, result, message = decrypt(key.encode('ascii'), msg, netif)
         print("command: ", command)
         print("result: ", result)
         print("message: ", message)
    else:
         print("no messages recieved")
