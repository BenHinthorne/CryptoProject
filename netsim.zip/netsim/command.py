import os

def CWD_down(folder):
    osString = folder + "/"
    try:
        os.chdir(osString)
    except OSError:
        print("Moving into folder %s has failed" %s)
        print("Check Spelling?")
    else:
        print("successfully moved into folder ", folder)

def CWD_one_level_up():
    if (os.path.curdir == ""):
        print("You cannot backtrack any more directories")
    else:
        os.chdir("..")

def LST():
    os.system("ls")

def GWD():
    os.getcwd()

def INIT(clientString):
    osString = "SERVER/" + clientString
    os.chdir(osString)
    print("You are currently in")
    os.system("pwd")

def main():
    print(os.path.curdir)
    print(os.system("pwd"))


main()
