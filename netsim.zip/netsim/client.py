#!/usr/bin/env python3
#sender.py

import os, sys, getopt, time
from netinterface import network_interface
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from Crypto.Cipher import AES
from Crypto import Random
from datetime import datetime
from enc_dec import encrypt, decrypt
from client_helper import checkandDecMessageswithBlocking, checkandDecMessageswithoutBlocking

NET_PATH = './'
OWN_ADDR = 'A'

# ------------
# main program
# ------------
# owd for user a
try:
	opts, args = getopt.getopt(sys.argv[1:], shortopts='hp:a:', longopts=['help', 'path=', 'addr='])
except getopt.GetoptError:
	print('Usage: python sender.py -p <network path> -a <own addr>')
	sys.exit(1)

for opt, arg in opts:
	if opt == '-h' or opt == '--help':
		print('Usage: python sender.py -p <network path> -a <own addr>')
		sys.exit(0)
	elif opt == '-p' or opt == '--path':
		NET_PATH = arg
	elif opt == '-a' or opt == '--addr':
		OWN_ADDR = arg

if (NET_PATH[-1] != '/') and (NET_PATH[-1] != '\\'): NET_PATH += '/'

if not os.access(NET_PATH, os.F_OK):
	print('Error: Cannot access path ' + NET_PATH)
	sys.exit(1)

if len(OWN_ADDR) > 1: OWN_ADDR = OWN_ADDR[0]

if OWN_ADDR not in network_interface.addr_space:
	print('Error: Invalid address ' + OWN_ADDR)
	sys.exit(1)

#KEYS FOR RSA, UNCOMMENT FOR FIRST RUN
#key = RSA.generate(2048)
#with open('private_key.pem',"wb") as f:
    #f.write(key.export_key('PEM'))

#with open('public_key.pem',"wb") as f:
#    f.write(key.publickey().export_key('PEM'))

public_key = ""
with open("public_key.pem", "rb") as f:
	public_key = RSA.import_key(f.read())

cipher_encrypt = PKCS1_OAEP.new(public_key)


#decode the verification message from the server
def verify_server(msg, key):
	nonce = msg[0:8]
	contents = msg[8:16]
	authtag = msg[-12:]
	authtage_len = 12
	AE = AES.new(key, AES.MODE_GCM, nonce = nonce, mac_len = authtage_len)
	AE.update(nonce)
	try:
		payload = AE.decrypt_and_verify(contents, authtag)
	except Exception as e:
		print("Error: Operation failed!")
		print("Terminating Session.")
		sys.exit(1)
	return payload.decode('ascii')



# main loop
netif = network_interface(NET_PATH, OWN_ADDR)
print('Initatiing session...')
dst = input('Type a destination address: ')

while True:
	#first receive the session key
	valid_key = False
	while valid_key == False:
		key = input('Input your session key: ')
		if len(key) != 16:
			print("Key must be 16 bytes long")
		else:
			valid_key = True
	#message sent to server for establishment
	confirmation = "SUCCESS!"
	time_stamp = str(datetime.now().strftime('%m/%d/%y %H:%M:%S'))
	msg = OWN_ADDR + time_stamp + confirmation + key

	#send establishment message to server
	ciphertext = cipher_encrypt.encrypt(msg.encode('utf-8'))
	netif.send_msg(dst, ciphertext)

	print("Wating for server verification...")
	server_verified = False
	while server_verified == False:
		status, msg = netif.receive_msg(blocking=True)
		response = verify_server(msg, key.encode('ascii'))
		if response == confirmation:
			print("Server verified successfully!")
			server_verified = True
		elif response == "FRESHNESS_ERROR":
			print("Server terminated sessoin")
			print("Reason: ", response)
			sys.exit(1)
		else:
			print("Server verificaton failed, terminating session")
			fail_message = "AUTHENTICATION FAILURE"
			##if authentication has failed, send a fail message to seever
			encrypt(OWN_ADDR, key.encode('ascii'), "ECS", "", fail_message, 0, dst, netif)
			sys.exit(1)
	if(server_verified == False):
		break
	else:
		password = input('Please log into the server with your password: ')
		encrypt(OWN_ADDR, key.encode('ascii'), "LGN", "", password, 0, dst, netif)

	print("Waiting for server response...")
	password_accepted = False
	while(password_accepted == False):
		status, msg = netif.receive_msg(blocking=True)
		command, result, message, ctr = decrypt(key.encode('ascii'), msg, netif)
		if(result.decode() == "SUCCESS!"):
			password_accepted = True
		if(result.decode() == "FAIL!"):
			print(message.decode())
			print("Terminating session...")
			sys.exit(1)
	break
print("Beginning Session...")
session_running = True
CTR_send = 0
CTR_recieve = 0

while session_running:
    print("receiving Messages")
    print("[type h for help][type ECS to end current session] ")
    acceptable_cmds = ["h", "MKD", "RMD", "GWD", "CWD", "LST", "UPL", "DWN", "RMF", "ECS"]
    command = input("enter command here: ")

    if command == "h":
        print("Supported Commands: ")
        print("MKD: Make a directory")
        print("RMD: Remove a directory")
        print("GWD: Obtain the name of the current directory on the server")
        print("CWD: Change the current folder on the server.")
        print("LST: List the contents of the current directory")
        print("UPL: Upload a file to the server")
        print("DWN: Download a file from the server")
        print("RMF: Remove a file")
        print("EC: End current session")
        print("")
    elif command == "MKD":
        print("Command: Make a folder on the directory ")
        createFileName = input("What do you want your file to be named? :")
        encrypt(OWN_ADDR, key.encode('ascii'), "MKD", createFileName, "Make a Dir", CTR_send, dst, netif)
        CTR_send += 1
        ans = checkandDecMessageswithBlocking(netif, key)
        print("File created sucessfully? ", ans)
    elif command == "RMD":
        print("Command: Remove a folder from the directory")
        remInput = input("What folder do you want to remove? :")
        if (remInput == ""):
            print("ERROR >> input cannot be blank ")
            continue
        encrypt(OWN_ADDR, key.encode('ascii'), "RMD", remInput, "Remove a directory", CTR_send, dst, netif)
        CTR_send+= 1
        ans = checkandDecMessageswithBlocking(netif, key)
        print("removing file ", remInput, "successfully? ", ans)
    elif command == "GWD":
        print("Command: Obtain the name of the current folder you are in")
        encrypt(OWN_ADDR, key.encode('ascii'), "GWD", "", "Get your current Dir", CTR_send, dst, netif)
        CTR_send += 1
        ans = checkandDecMessageswithBlocking(netif, key)
    elif command == "CWD":
        print("Command: Change the current folder you are in")
        print("Note: use CRD: Change to Root Directory to backtrack out of directories")
        cwdInput = input("What file do you want to move into? :")
        encrypt(OWN_ADDR, key.encode('ascii'), "CWD", cwdInput, "change to directory", CTR_send, dst, netif)
        CTR_send += 1
        ans = checkandDecMessageswithBlocking(netif, key)
        print("moving into new directory sucessful?", ans)
    elif command == "CRD":
        print("Command: change to the root directory")
        encrypt(OWN_ADDR, key.encode('ascii'), "CRD", "", "change to root directory", CTR_send, dst, netif)
        CTR_send += 1
        ans = checkandDecMessageswithBlocking(netif, key)
        print("moving into root directory successful?", ans)
    elif command == "LST":
        print("Command: List the contents of the folder you are in")
        encrypt(OWN_ADDR, key.encode('ascii'), "LST", "", "List curr directory contents", CTR_send, dst, netif)
        CTR_send += 1
        ans = checkandDecMessageswithBlocking(netif, key)
        print("listing directory contents successful?", ans)
    elif command == "UPL":
        print("Command: Upload a file to the server")
        CTR_send += 1
        fileNameInput = input("What do you want your fileName to be?: ")
        fileContentsInput = input("What do you want your file contents to be?: ")
        encrypt(OWN_ADDR, key.encode('ascii'), "UPL", fileNameInput, fileContentsInput, CTR_send, dst, netif)
        CTR_send += 1
        ans = checkandDecMessageswithBlocking(netif, key)
        print("uploaded file successful?", ans)
    elif command == "DWN":
        print("Command: Download a file from the server")
        fileNameInput = input("What file do you want to download? : ")
        encrypt(OWN_ADDR, key.encode('ascii'), "DWN", fileNameInput, "", CTR_send, dst, netif)
        CTR_send += 1
        ans = checkandDecMessageswithBlocking(netif, key)
        print("download file successful?", ans)
    elif command == "RMF":
        print("Command: Remove a file from the server")
        fileNameInput = input("What file do you want to delete? : ")
        encrypt(OWN_ADDR, key.encode('ascii'), "RMF", fileNameInput, "", CTR_send, dst, netif)
        CTR_send += 1
        ans = checkandDecMessageswithBlocking(netif, key)
        print("delete file successful?", ans)

    elif command == "ECS":
        print("Command: End current session")
        CTR_send += 1
        encrypt(OWN_ADDR, key.encode('ascii'), "ECS", "", "End Current Session", CTR_send, dst, netif)
        ans = checkandDecMessageswithBlocking(netif, key)
        if ans:
             print("ending session")
             session_running = False
    else:
        print(">> Error >> Please enter a supported command")

    print("")

print("Session Over")
