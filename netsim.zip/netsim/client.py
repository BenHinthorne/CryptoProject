#!/usr/bin/env python3
#sender.py

import os, sys, getopt, time
from netinterface import network_interface
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from Crypto.Cipher import AES
from Crypto import Random
from datetime import datetime
from enc_dec import encrypt, decrypt

NET_PATH = './'
OWN_ADDR = 'A'

# ------------
# main program
# ------------

try:
	opts, args = getopt.getopt(sys.argv[1:], shortopts='hp:a:', longopts=['help', 'path=', 'addr='])
except getopt.GetoptError:
	print('Usage: python sender.py -p <network path> -a <own addr>')
	sys.exit(1)

for opt, arg in opts:
	if opt == '-h' or opt == '--help':
		print('Usage: python sender.py -p <network path> -a <own addr>')
		sys.exit(0)
	elif opt == '-p' or opt == '--path':
		NET_PATH = arg
	elif opt == '-a' or opt == '--addr':
		OWN_ADDR = arg

if (NET_PATH[-1] != '/') and (NET_PATH[-1] != '\\'): NET_PATH += '/'

if not os.access(NET_PATH, os.F_OK):
	print('Error: Cannot access path ' + NET_PATH)
	sys.exit(1)

if len(OWN_ADDR) > 1: OWN_ADDR = OWN_ADDR[0]

if OWN_ADDR not in network_interface.addr_space:
	print('Error: Invalid address ' + OWN_ADDR)
	sys.exit(1)

#KEYS FOR RSA, UNCOMMENT FOR FIRST RUN
#key = RSA.generate(2048)
#with open('private_key.pem',"wb") as f:
    #f.write(key.export_key('PEM'))

#with open('public_key.pem',"wb") as f:
#    f.write(key.publickey().export_key('PEM'))

public_key = ""
with open("public_key.pem", "rb") as f:
	public_key = RSA.import_key(f.read())

cipher_encrypt = PKCS1_OAEP.new(public_key)


#decode the verification message from the server
def verify_server(msg, key):
	nonce = msg[0:8]
	contents = msg[8:16]
	authtag = msg[-12:]
	authtage_len = 12
	AE = AES.new(key, AES.MODE_GCM, nonce = nonce, mac_len = authtage_len)
	AE.update(nonce)
	try:
		payload = AE.decrypt_and_verify(contents, authtag)
	except Exception as e:
		print("Error: Operation failed!")
		print("Terminating Session.")
		sys.exit(1)
	return payload.decode('ascii')



# main loop
netif = network_interface(NET_PATH, OWN_ADDR)
print('Initatiing session...')
dst = input('Type a destination address: ')

while True:
	#first receive the session key
	valid_key = False
	while valid_key == False:
		key = input('Input your session key: ')
		if len(key) != 16:
			print("Key must be 16 bytes long")
		else:
			valid_key = True
	#message sent to server for establishment
	confirmation = "SUCCESS!"
	time_stamp = str(datetime.now().strftime('%m/%d/%y %H:%M:%S'))
	msg = OWN_ADDR + time_stamp + confirmation + key

	#send establishment message to server
	ciphertext = cipher_encrypt.encrypt(msg.encode('utf-8'))
	netif.send_msg(dst, ciphertext)


	print("Wating for server verification...")
	server_verified = False
	while server_verified == False:
		status, msg = netif.receive_msg(blocking=True)
		response = verify_server(msg, key.encode('ascii'))
		if response == confirmation:
			print("Server verified successfully!")
			server_verified = True
		elif response == "FRESHNESS_ERROR":
			print("Server terminated sessoin")
			print("Reason: ", response)
			sys.exit(1)
		else:
			print("Server verificaton failed, terminating session")
			fail_message = "AUTHENTICATION FAILURE"
			##if authentication has failed, send a fail message to seever
			encrypt(OWN_ADDR, key.encode('ascii'), "ECS", "", fail_message, 0, dst, netif)
			sys.exit(1)
	if(server_verified == False):
		break
	else:
		password = input('Please log into the server with your password: ')
		encrypt(OWN_ADDR, key.encode('ascii'), "LGN", "", password, 0, dst, netif)

	print("Waiting for server response...")
	password_accepted = False
	while(password_accepted == False):
		status, msg = netif.receive_msg(blocking=True)
		command, result, message = decrypt(key.encode('ascii'), msg, netif)
		if(result.decode() == "SUCCESS!"):
			password_accepted = True
		if(result.decode() == "FAIL!"):
			print(message.decode())
			print("Terminating session...")
			sys.exit(1)
	break
print("Beggining Session...")

while True:
	command = input("Input your command: ")
	arguments = input("Input your arguments: ")
