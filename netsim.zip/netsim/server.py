#!/usr/bin/env python3
#receiver.py

import os, sys, getopt, time
from netinterface import network_interface
from datetime import datetime, timedelta

from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from Crypto.Cipher import AES
from Crypto import Random
from enc_dec import encrypt, decrypt
NET_PATH = './'
OWN_ADDR = 'B'

# ------------
# main program
# ------------

try:
	opts, args = getopt.getopt(sys.argv[1:], shortopts='hp:a:', longopts=['help', 'path=', 'addr='])
except getopt.GetoptError:
	print('Usage: python receiver.py -p <network path> -a <own addr>')
	sys.exit(1)

for opt, arg in opts:
	if opt == '-h' or opt == '--help':
		print('Usage: python receiver.py -p <network path> -a <own addr>')
		sys.exit(0)
	elif opt == '-p' or opt == '--path':
		NET_PATH = arg
	elif opt == '-a' or opt == '--addr':
		OWN_ADDR = arg

if (NET_PATH[-1] != '/') and (NET_PATH[-1] != '\\'): NET_PATH += '/'

if not os.access(NET_PATH, os.F_OK):
	print('Error: Cannot access path ' + NET_PATH)
	sys.exit(1)

if len(OWN_ADDR) > 1: OWN_ADDR = OWN_ADDR[0]

if OWN_ADDR not in network_interface.addr_space:
	print('Error: Invalid address ' + OWN_ADDR)
	sys.exit(1)

private_key = ""
with open('private_key.pem', "rb") as f:
    private_key = RSA.import_key(f.read())

public_key = ""
with open("public_key.pem", "rb") as f:
	public_key = RSA.import_key(f.read())

cipher_decrypt = PKCS1_OAEP.new(private_key)
cipher_encrypt = PKCS1_OAEP.new(public_key)


#send the session establishment verificatin message to the client
def send_verification_msg(msg, key):
	nonce = Random.get_random_bytes(8)
	message = msg
	authtag_length = 12
	AE = AES.new(key, AES.MODE_GCM, nonce=nonce, mac_len = authtag_length)
	AE.update(nonce)
	encrypted_payload, authtag = AE.encrypt_and_digest(msg.encode('ascii'))
	message = nonce + encrypted_payload + authtag
	netif.send_msg(client_addr, message)



#method when a password is recieved from the client
def on_pwd_receive(user_id, pwd_attempt, key,dst):

	dir = './SERVER/' + user_id
	path = dir + '/password.txt'
	#check if the user already exists
	if os.path.exists(path):
		#if they do try and verify their passowrd
		with open(path, 'rb') as file:
			user_pwd = file.read()
			decrypted_pwd = cipher_decrypt.decrypt(user_pwd)
			decrypted_pwd = decrypted_pwd.decode()
			if(pwd_attempt == decrypted_pwd):
				encrypt(OWN_ADDR, key, "CRC", "SUCCESS!", "Password verified successfully", 0,dst, netif)
				print("Password verified successfully")
				return True
			else:
				encrypt(OWN_ADDR, key, "CRC", "FAIL!", "Password Incorrect!", 0,dst, netif)
				print("Incorrect password!!")
				print("Terminating session...")
				sys.exit(1)
				return False
	#if the user does not exist, create a directory for them
	else:
		os.mkdir(dir)
		with open(path, 'wb') as file:
			encrypted_pwd = cipher_encrypt.encrypt(pwd_attempt.encode('utf-8'))
			file.write(encrypted_pwd)
			message = "Registered new user with id: " + dst
			encrypt(OWN_ADDR, key, "CRC", "SUCCESS!", message, 0,dst, netif)
			print("New user registered")
			return True





# main loop
netif = network_interface(NET_PATH, OWN_ADDR)
print('Main loop started...')
print('Wating for session establishment...')
while True:
# Calling receive_msg() in non-blocking mode ...
#	status, msg = netif.receive_msg(blocking=False)
#	if status: print(msg)      # if status is True, then a message was returned in msg
#	else: time.sleep(2)        # otherwise msg is empty

# Calling receive_msg() in blocking mode ...
	##First wait for any message to be sent
	establish_attempt = False
	while establish_attempt == False:
		status, msg = netif.receive_msg(blocking=True)    # when returns, status is True and msg contains a message
		if status:
			##the first message should be establishing a session
			establish_attempt = True
			decrypted_message = cipher_decrypt.decrypt(msg)
			decrypted_message = decrypted_message.decode()
			client_addr = decrypted_message[0]
			time_stamp = decrypted_message[1:18]
			time_object = datetime.strptime(time_stamp, '%m/%d/%y %H:%M:%S')
			confirmation = decrypted_message[18:26]
			session_key = decrypted_message[26:]

			#check for freshness
			if time_object > datetime.now()-timedelta(seconds=3):
				print("Attempting to establish session with clent...")
				send_verification_msg(confirmation, session_key.encode('utf-8'))
			else:
				print("Error: Session establishment not fresh")
				print("Ending session...")
				#sending fail message back to client
				send_verification_msg("FAIL", session_key.encode('utf-8'))
				sys.exit(1)

	##after verification, wait for password from client
	print("Waiting for password from client...")
	pwd_accepted = False
	while pwd_accepted == False:
		status, msg = netif.receive_msg(blocking=True)
		if status:
			command, filename, message = decrypt(session_key.encode('ascii'), msg, netif)
			if(command.decode()[:3] == "LGN"):
				pwd_accepted = on_pwd_receive(client_addr, message.decode(), session_key.encode('ascii'), client_addr)
			#client will end session if password is not verified correctly
			#so we end our ession as well
			if(command.decode()[:3] == "ECS"):
				print("Client terminated session, reason:")
				print(message.decode())
				print("Ending current session...")
				sys.exit(1)

	print("Beginning session with user: " + client_addr)
