from enc_dec import encrypt, decrypt
import sys
SERVER_ID = "B"

def checkandDecMessageswithBlocking(netif, key, CTR_receive):
    status, msg = netif.receive_msg(blocking=True)
    if status:
        command, result, message, ctr, id = decrypt(key.encode('latin1'), msg, netif )
        command = command.decode('ascii')[:-1]
        ctr = int.from_bytes(ctr, byteorder='big')
        print("ctr: ", ctr)
        print("CTR_receive", CTR_receive)
		##Check to make sure message is from the server
        if(id.decode()[0] != SERVER_ID):
            print("Invalid Sender")
            sys.exit(1)
        if (ctr != CTR_receive):
            print("Terminating Session")
            print("Reason: Server CTR Error")
            sys.exit(1)
        else:
            print("CTR Correct")
        if (command == "CRC"):
            return True, result, message
        elif(command == "CTE"):
            print("Terminating Session")
            print("Reason: Counter Error")
            sys.exit(1)
        else:
            return False, result, message
