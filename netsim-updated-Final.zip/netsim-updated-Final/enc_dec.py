import os, sys, getopt, time
from netinterface import network_interface
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from Crypto.Cipher import AES
from Crypto import Random
from datetime import datetime


##helper for formatting messages
def autoformatter(bytestring, desiredlength):
    for i in range(0, (desiredlength - len(bytestring))):
        bytestring += b'\x00'
    return bytestring

##Encrypt and send messages with GCM
def encrypt(ID_string, SKey, CMD_string,
            fileNameString, filecontentsFile, CTR_int, dst, netif):
	IV = Random.get_random_bytes(8) # may need to change this
	ID = ID_string.encode('ascii')
	CMD = CMD_string.encode('ascii')
	FN = fileNameString.encode('ascii')
	FC = filecontentsFile.encode('ascii')
	CTR = CTR_int.to_bytes(4, byteorder='big')

	FNLength = len(FN).to_bytes(4, byteorder='big')
	FCLength = len(FC).to_bytes(4, byteorder='big')
	ID = autoformatter(ID, 8)
	CMD = autoformatter(CMD, 4)
	header = FNLength + FCLength + IV
	payload = ID + CTR + CMD + FN + FC
	authtag_length = 12
	#AE = AES.new(SKey, AES.MODE_GCM, nonce=IV, mac_len=authtag_length)
	AE = AES.new(SKey, AES.MODE_GCM, nonce=IV, mac_len=authtag_length)
	AE.update(header)
	encrypted_payload, authtag = AE.encrypt_and_digest(payload)
	message = header + encrypted_payload + authtag
	netif.send_msg(dst, message)

##Decrypt and return contents of messages with GCM
def decrypt(key, msg, netif):
    try:
        message = msg
        FNLength = int.from_bytes(message[0:4], byteorder='big')
        FCLength = int.from_bytes(message[4:8], byteorder='big')
        IV = message[8:16]
        authtag_length = 12
        authtag = message[-12:]
        header = message[0:16]
        encrypted_payload = message[16:-12]
        AE = AES.new(key, AES.MODE_GCM, nonce=IV, mac_len=authtag_length)
        AE.update(header)
        try:
	        payload = AE.decrypt_and_verify(encrypted_payload, authtag)
        except Exception as e:
	        print("Error: Operation failed!")
	        print("Processing completed.")
	        sys.exit(1)

        id = payload[0:8]
        command = payload[12:16]
        filename = payload[16:(16+FNLength)]
        filecontents = payload[16+FNLength:(16+FNLength+FCLength)]
        ctr = payload[8:12]
        #Check if message is from the server
        return command, filename, filecontents, ctr, id
    except:
        print("Error in message formatting")
        sys.exit(1)
