import os

def MKD(clientString, FileName):
    osString = "mkdir SERVER/" + clientString + "/" + FileName + "/"
    print(osString)
    try:
        os.system(osString)
    except OSError:
        print ("Creation of the directory %s failed" % osString)
    else:
        print ("Successfully created the directory %s " % osString)

def RMD(clientString, FileName): #still buggy as all hell
    try:
        osString = "rmdir SERVER/" + clientString + "/" + FileName + "/"
    except OSError:
        print("Removal of the directory %s failed" % osString)
    else:
        print("Successfully removed the directory %s" % osString)

def LST(clientString):
    osString = 'ls SERVER/' + clientString
    os.system(osString)



def UPL(clientString, FileName, FileContents): #can create a file, cant write to it
    osString = 'SERVER/' + clientString + "/" + FileName
    os.system(osString)
    fileOpenString = 'SERVER/' + clientString + "/" + FileName
    print()

def GWD()

def main():
    LST('A')
    # MKD("A", "photos")
    RMD("A", "photos")

main()
