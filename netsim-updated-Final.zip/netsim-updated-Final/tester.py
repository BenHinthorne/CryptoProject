c = b'ECS\x00'
print(str(c.decode('ascii')))
c = str(c.decode('ascii'))
c = c[:-1]
if (c == "ECS"):
    print("yes")
