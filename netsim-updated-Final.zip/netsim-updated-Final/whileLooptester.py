while True:
    print("[type h for help][type ECS to end current session] ")
    acceptable_cmds = ["h", "MKD", "RMD", "GWD", "CWD", "LST", "UPL", "DWN", "RMF", "ECS"]
    command = input("enter command here: ")
    if (command == "h"):
        print("Supported Commands: ")
        print("MKD: Make a directory")
        print("RMD: Remove a directory")
        print("GWD: Obtain the name of the current irectory on the server")
        print("CWD: Change the current folder on the server.")
        print("")

    elif (command == "MKD"):
        print("Command: Make a Directory")
        FileName = input("Input File Name: ")

    else:
        print("Please enter a supported command")
